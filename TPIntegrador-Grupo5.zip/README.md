# Teoria De La Información
## Facultad de Ingenieria - UNMdP

### Grupo 5
- Noelia Echeverria
- Camila Ezama
- Juan Cruz Mateos

